export type TeamId = "CHN" | "PHI" | "IRI" | "AUS" | "KOR" | "JPN";
export type EraId = "founding" | "china" | "west" | "oceania";

export const TEAM_IDS: TeamId[] = ["CHN", "PHI", "IRI", "AUS", "KOR", "JPN"];

export const TEAMS: Record<TeamId, { en: string; ru: string; swatch: string }> = {
  CHN: { en: "China", ru: "Китай", swatch: "bg-team-chn" },
  PHI: { en: "Philippines", ru: "Филиппины", swatch: "bg-team-phi" },
  IRI: { en: "Iran", ru: "Иран", swatch: "bg-team-iri" },
  AUS: { en: "Australia", ru: "Австралия", swatch: "bg-team-aus" },
  KOR: { en: "South Korea", ru: "Южная Корея", swatch: "bg-team-kor" },
  JPN: { en: "Japan", ru: "Япония", swatch: "bg-team-jpn" },
};

export const ERAS: { id: EraId; from: number; to: number }[] = [
  { id: "founding", from: 1960, to: 1973 },
  { id: "china", from: 1975, to: 2005 },
  { id: "west", from: 2007, to: 2015 },
  { id: "oceania", from: 2017, to: 2025 },
];

export type Edition = { year: number; team: TeamId; era: EraId };

const RAW: [number, TeamId, EraId][] = [
  [1960, "PHI", "founding"],
  [1963, "PHI", "founding"],
  [1965, "JPN", "founding"],
  [1967, "PHI", "founding"],
  [1969, "KOR", "founding"],
  [1971, "JPN", "founding"],
  [1973, "PHI", "founding"],
  [1975, "CHN", "china"],
  [1977, "CHN", "china"],
  [1979, "CHN", "china"],
  [1981, "CHN", "china"],
  [1983, "CHN", "china"],
  [1985, "PHI", "china"],
  [1987, "CHN", "china"],
  [1989, "CHN", "china"],
  [1991, "CHN", "china"],
  [1993, "CHN", "china"],
  [1995, "CHN", "china"],
  [1997, "KOR", "china"],
  [1999, "CHN", "china"],
  [2001, "CHN", "china"],
  [2003, "CHN", "china"],
  [2005, "CHN", "china"],
  [2007, "IRI", "west"],
  [2009, "IRI", "west"],
  [2011, "CHN", "west"],
  [2013, "IRI", "west"],
  [2015, "CHN", "west"],
  [2017, "AUS", "oceania"],
  [2022, "AUS", "oceania"],
  [2025, "AUS", "oceania"],
];

export const EDITIONS: Edition[] = RAW.map(([year, team, era]) => ({ year, team, era }));

export type MedalRow = { team: TeamId; g: number; s: number; b: number };

export const MEDALS: MedalRow[] = [
  { team: "CHN", g: 16, s: 2, b: 2 },
  { team: "PHI", g: 5, s: 4, b: 1 },
  { team: "IRI", g: 3, s: 1, b: 2 },
  { team: "AUS", g: 3, s: 0, b: 0 },
  { team: "KOR", g: 2, s: 11, b: 12 },
  { team: "JPN", g: 2, s: 5, b: 7 },
];

/** Runner-up only where a published final was checked. Not used in the HHI. */
export const FINALS: { year: number; runnerEn: string; runnerRu: string }[] = [
  { year: 2007, runnerEn: "Lebanon", runnerRu: "Ливан" },
  { year: 2009, runnerEn: "China", runnerRu: "Китай" },
  { year: 2011, runnerEn: "Jordan", runnerRu: "Иордания" },
  { year: 2013, runnerEn: "Philippines", runnerRu: "Филиппины" },
  { year: 2015, runnerEn: "Philippines", runnerRu: "Филиппины" },
  { year: 2017, runnerEn: "Iran", runnerRu: "Иран" },
  { year: 2022, runnerEn: "Lebanon", runnerRu: "Ливан" },
  { year: 2025, runnerEn: "China", runnerRu: "Китай" },
];

export const NOTES: Partial<Record<number, { en: string; ru: string }>> = {
  1960: {
    en: "First edition, in Manila. The Asian Championship begins, and the Philippines win it.",
    ru: "Первый турнир, Манила. С него начинается чемпионат Азии, и его берут Филиппины.",
  },
  1975: {
    en: "China debuts and wins. The study uses this as the break that opens the China era.",
    ru: "Дебют и первая победа Китая. В работе это граница, с которой открывается эра Китая.",
  },
  1985: {
    en: "The Philippines break a long Chinese run — the only other champion between 1975 and 1995.",
    ru: "Филиппины прерывают длинную серию Китая — единственный другой чемпион между 1975 и 1995.",
  },
  1997: {
    en: "South Korea’s second title, late in the China era.",
    ru: "Второй титул Южной Кореи, уже в конце эры Китая.",
  },
  2007: {
    en: "Iran’s first title opens the West Asian window. The study notes China did not always send its strongest side, including in 2007.",
    ru: "Первый титул Ирана открывает окно Западной Азии. В работе отмечено: Китай не всегда выставлял сильнейший состав, в том числе в 2007.",
  },
  2017: {
    en: "Oceania joins. The event is now the FIBA Asia Cup, on a four-year cycle, and Australia wins.",
    ru: "Входит Океания. Турнир становится FIBA Asia Cup на четырёхлетнем цикле, и побеждает Австралия.",
  },
  2022: {
    en: "Australia again. The published calendar put this edition in Jakarta in July 2022, after a postponement from 2021.",
    ru: "Снова Австралия. В опубликованном календаре турнир прошёл в Джакарте в июле 2022-го, после переноса с 2021-го.",
  },
  2025: {
    en: "Australia’s third title in three editions. For this window the HHI is 1.00.",
    ru: "Третий титул Австралии в трёх розыгрышах. Для этого окна HHI равен 1.00.",
  },
};

export function hhi(counts: number[]): number {
  const total = counts.reduce((sum, n) => sum + n, 0);
  if (total <= 0) return 0;
  return counts.reduce((sum, n) => sum + (n / total) ** 2, 0);
}

export function emptyCounts(): Record<TeamId, number> {
  return { CHN: 0, PHI: 0, IRI: 0, AUS: 0, KOR: 0, JPN: 0 };
}

export function countsFor(editions: Edition[]): Record<TeamId, number> {
  const counts = emptyCounts();
  for (const edition of editions) counts[edition.team] += 1;
  return counts;
}

export function summarize(editions: Edition[]) {
  const counts = countsFor(editions);
  const values = TEAM_IDS.map((id) => counts[id]);
  const total = editions.length;
  const index = hhi(values);
  let leader: TeamId = "CHN";
  let best = -1;
  for (const id of TEAM_IDS) {
    if (counts[id] > best) {
      best = counts[id];
      leader = id;
    }
  }
  const champions = TEAM_IDS.filter((id) => counts[id] > 0).length;
  return {
    total,
    champions,
    hhi: index,
    leader,
    leaderShare: total ? best / total : 0,
    eff: index > 0 ? 1 / index : 0,
    counts,
  };
}

export function formatHhi(value: number): string {
  return value.toFixed(2);
}

export function formatShare(value: number): string {
  return `${Math.round(value * 100)}%`;
}

export function formatEff(value: number): string {
  return value.toFixed(2);
}

export const REFERENCES: { text: string; href?: string }[] = [
  {
    text: "Brieflands. (n.d.). Game-related statistics which discriminate between winning and losing teams in Asian and European men’s basketball championships. Authors, year and journal still to be completed on the poster.",
  },
  {
    text: "FIBA. (n.d.). FIBA Asia Cup: History.",
    href: "https://www.fiba.basketball/en/history/195-fiba-asia-cup",
  },
  {
    text: "Fort, R., & Maxcy, J. (2003). Competitive balance in sports leagues: An introduction. Journal of Sports Economics, 4(2), 154–160.",
  },
  {
    text: "Humphreys, B. R. (2002). Alternative measures of competitive balance in sports leagues. Journal of Sports Economics, 3(2), 133–148.",
  },
  {
    text: "Rottenberg, S. (1956). The baseball players’ labor market. Journal of Political Economy, 64(3), 242–258.",
  },
  {
    text: "SAGE Open. (2024). Market share instability and market concentration: A sport/discipline-specific study of the Summer Olympic Games 1992–2020. Authors, volume and DOI still to be completed on the poster.",
  },
  {
    text: "Truyens, J., De Bosscher, V., & Heyndels, B. Competitive balance in athletics. Managing Sport and Leisure. Year, volume and pages still to be completed on the poster.",
  },
  {
    text: "Wikipedia contributors. (2026). FIBA Asia Cup. Accessed 3 November 2026.",
    href: "https://en.wikipedia.org/wiki/FIBA_Asia_Cup",
  },
  {
    text: "Supplementary finals, 2007–2025, checked against published tournament pages (not an input to the HHI): Wikipedia, 2022 FIBA Asia Cup; RealGM FIBA Asia Cup history. Accessed 3 November 2026.",
    href: "https://en.wikipedia.org/wiki/2022_FIBA_Asia_Cup",
  },
];
