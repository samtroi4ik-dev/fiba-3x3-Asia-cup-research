import type { EraId } from "@/data/cup";

export type Lang = "ru" | "en";

export type Ui = {
  skip: string;
  nav: { answer: string; years: string; index: string; method: string; meaning: string; sources: string };
  kicker: string;
  titleA: string;
  titleB: string;
  deck: string;
  byline: string;
  questionLabel: string;
  question: string;
  aimLabel: string;
  aim: string;
  answerLabel: string;
  answer: string;
  copyAnswer: string;
  copied: string;
  statHhi: string;
  statHhiLabel: string;
  statChina: string;
  statChinaLabel: string;
  statAus: string;
  statAusLabel: string;
  yearsTitle: string;
  yearsLead: string;
  allEras: string;
  allTeams: string;
  tapYear: string;
  editionsNote: string;
  championWord: string;
  finalWord: string;
  indexTitle: string;
  indexLead: string;
  colEra: string;
  colEditions: string;
  colChampions: string;
  colHhi: string;
  colLeader: string;
  colEff: string;
  allEra: string;
  hhiCaption: string;
  medalTitle: string;
  medalLead: string;
  gold: string;
  silver: string;
  bronze: string;
  eraName: Record<EraId, string>;
  eraBody: Record<EraId, string>;
  eraShort: Record<EraId, string>;
  threeKicker: string;
  threeTitle: string;
  threeBody: string;
  methodTitle: string;
  methodLead: string;
  rows: { k: string; v: string }[];
  labTitle: string;
  labLead: string;
  labHint: string;
  labReset: string;
  labNow: string;
  labActual: string;
  labPool: string;
  labGive: string;
  labTake: string;
  meaningTitle: string;
  bullets: string[];
  limitTitle: string;
  limits: string[];
  closeTitle: string;
  closeBody: string;
  recs: string;
  sourcesTitle: string;
  sourcesNote: string;
  illus: string;
  footer: string;
  heroAlt: string;
  threeAlt: string;
  courtAlt: string;
  tunnelAlt: string;
};

export const ui: Record<Lang, Ui> = {
  ru: {
    skip: "К выводу",
    nav: {
      answer: "Вывод",
      years: "Годы",
      index: "Индекс",
      method: "Метод",
      meaning: "Смысл",
      sources: "Источники",
    },
    kicker: "Мини-исследование · 31 турнир",
    titleA: "Кто побеждает",
    titleB: "в азиатском баскетболе?",
    deck: "Концентрация титулов и конкурентный баланс на FIBA Asia Cup, 1960–2025.",
    byline: "Алдияр Аканов",
    questionLabel: "Вопрос",
    question:
      "Насколько сконцентрированы титулы FIBA Asia Cup и изменило ли включение Океании в 2017 году конкурентный баланс?",
    aimLabel: "Задача",
    aim: "Записать чемпионов всех 31 розыгрышей, посчитать HHI по четырём эрам и прочитать результат через теорию конкурентного баланса.",
    answerLabel: "Короткий ответ",
    answer:
      "Концентрация высокая и цикличная: общий HHI 0.32, 16 из 31 титула у Китая. Вход Океании в 2017-м баланс не улучшил — Австралия выиграла три турнира из трёх. Центр силы сдвинулся, а не размылся.",
    copyAnswer: "Скопировать ответ",
    copied: "Скопировано",
    statHhi: "0.32",
    statHhiLabel: "общий HHI титулов, 31 турнир",
    statChina: "16 / 31",
    statChinaLabel: "титулов Китая, все между 1975 и 2015",
    statAus: "18–0",
    statAusLabel: "серия Австралии на Asia Cup, 3 титула с 2017",
    yearsTitle: "Кто забирал кубок",
    yearsLead:
      "Шесть сборных побеждали хотя бы раз. Тридцать четыре выходили на турнир. Нажмите год или соберите эру — лента не выдумывает счёт, только чемпиона.",
    allEras: "Все эры",
    allTeams: "Все",
    tapYear: "Нажмите год, чтобы прочитать, что в нём важно для вопроса.",
    editionsNote:
      "На ленте розыгрыши, а не каждый календарный год. До 2015 турнир шёл раз в два года. С 2017 это отдельный FIBA Asia Cup.",
    championWord: "Чемпион",
    finalWord: "Финал",
    indexTitle: "Насколько это концентрировано",
    indexLead:
      "HHI — сумма квадратов долей титулов. Около 1/N это баланс, 1.00 значит один победитель. Среди шести чемпионов ровный дележ дал бы HHI 0.17. Фактические 0.32 почти вдвое выше: «эффективных» чемпионов всего 3.13.",
    colEra: "Эра",
    colEditions: "Турниры",
    colChampions: "Чемпионы",
    colHhi: "HHI",
    colLeader: "Доля лидера",
    colEff: "Эфф. чемпионы",
    allEra: "Все, 1960–2025",
    hhiCaption: "HHI титулов. 1.00 — одна сборная выигрывает всё. Цвет столбца — лидер эры.",
    medalTitle: "Титул — не вся глубина",
    medalLead:
      "Корея взяла лишь 2 золота, но 11 серебра и 12 бронзы. Япония — 2, 5 и 7. Одни титулы прячут, кто постоянно рядом с вершиной.",
    gold: "Золото",
    silver: "Серебро",
    bronze: "Бронза",
    eraName: {
      founding: "1960–1973",
      china: "1975–2005",
      west: "2007–2015",
      oceania: "2017–2025",
    },
    eraShort: {
      founding: "60–73",
      china: "75–05",
      west: "07–15",
      oceania: "17–25",
    },
    eraBody: {
      founding:
        "Семь турниров, три чемпиона. Филиппины берут четыре. HHI 0.43: уже тесно, но ещё не монополия. Япония и Корея уже в списке.",
      china:
        "Шестнадцать турниров. Китай — 14, плюс по одному у Филиппин (1985) и Кореи (1997). HHI 0.77, доля лидера 88%. Пик всей серии.",
      west:
        "Пять турниров, два чемпиона. Иран — 3, Китай — 2. HHI падает до 0.52. Финалы часто сводят Западную Азию с Восточной.",
      oceania:
        "Три турнира, один чемпион. Австралия 3 из 3, HHI 1.00. Океания перенесла центр силы, а не раздала титулы. В работе серия Австралии — 18–0.",
    },
    threeKicker: "Рядом, но не в выборке",
    threeTitle: "3×3 — другая игра",
    threeBody:
      "Это исследование про классический FIBA Asia Cup, пять на пять. Уличный 3×3 — отдельное соревнование FIBA, его титулы сюда не входят. Кадр только задаёт атмосферу и не является архивным фото матча.",
    methodTitle: "Как посчитано",
    methodLead:
      "Количественный разбор всей совокупности: каждый розыгрыш, без выборки и без опросов. Эры нарезаны по слому формата, а не по красивой дате.",
    rows: [
      {
        k: "Подход",
        v: "Количественный, описательный, продольный анализ вторичных данных. Живых участников нет.",
      },
      {
        k: "Почему так",
        v: "Исход — это счёт титулов, его можно сравнить между эрами одним числом.",
      },
      {
        k: "Источник",
        v: "Чемпионы всех 31 розыгрышей, 1960–2025, по опубликованным протоколам турнира.",
      },
      {
        k: "Совокупность",
        v: "Вся популяция. Эры: 1960–73; 1975–2005, дебют Китая; 2007–15, подъём Западной Азии; 2017–25, вход Океании.",
      },
      {
        k: "Инструменты",
        v: "HHI = сумма квадратов долей; доля лидера; эффективное число чемпионов = 1/HHI.",
      },
      {
        k: "Ход",
        v: "Список чемпионов, подсчёт по эрам, индексы, затем график.",
      },
      {
        k: "Этика",
        v: "Только открытые данные. Источники названы. Ничего не выдумано и не подправлено.",
      },
    ],
    labTitle: "Покрутите индекс сами",
    labLead:
      "Это учебный стенд, не новые данные. Снимите титул у одной сборной и отдайте другой. Общее число титулов остаётся 31.",
    labHint: "Сначала минус, потом плюс у другой сборной.",
    labReset: "Вернуть факт",
    labNow: "Сейчас",
    labActual: "В исследовании",
    labPool: "В руках",
    labGive: "Забрать титул",
    labTake: "Отдать титул",
    meaningTitle: "Что из этого следует",
    bullets: [
      "Ровного тренда нет. Концентрация пиковая в эру Китая (1975–2005), ниже в 2007–2015, когда три титула берёт Иран, и снова 1.00 после 2017.",
      "Неожиданность гипотезы подтверждается: Океания не размазала успех. Австралия выиграла все три розыгрыша, центр силы переехал.",
      "Это стыкуется с Truyens et al. и SAGE Open (2024): концентрация держится, даже когда участников становится больше.",
    ],
    limitTitle: "Где работа слабее",
    limits: [
      "В последней эре всего три турнира. Один победитель автоматически даёт HHI 1.00.",
      "Китай не всегда выставлял сильнейший состав, например в 2007.",
      "Титулы не видят глубину медалей. Данные вторичные.",
    ],
    closeTitle: "Ответ на вопрос",
    closeBody:
      "Концентрация титулов на FIBA Asia Cup высокая и цикличная (общий HHI 0.32; 16 из 31 — у Китая). Вход Океании в 2017 году баланс не улучшил: Австралия лидирует с 3 из 3.",
    recs: "Дальше баланс лучше мерить медалями и топ-4, не только титулами. Имеет смысл добавить разницу в счёте и динамическую меру устойчивости чемпионов.",
    sourcesTitle: "Источники",
    sourcesNote:
      "Библиография как на постере. Где на постере стояла пометка «дописать автора», она сохранена — недостающее не додумано.",
    illus:
      "Кадры площадки и 3×3 — сгенерированные иллюстрации, не фото конкретных матчей и не портреты игроков. На них нельзя опираться как на доказательство.",
    footer: "Who Wins · мини-исследование по FIBA Asia Cup",
    heroAlt: "Иллюстрация: бросок в пустом свете ночной арены, без номеров и без узнаваемого лица.",
    threeAlt: "Иллюстрация: уличный момент 3×3 на закате, лица не читаются.",
    courtAlt: "Иллюстрация: пустая площадка и одно пятно тёплого света.",
    tunnelAlt: "Иллюстрация: силуэты игроков уходят с освещённой площадки в туннель.",
  },
  en: {
    skip: "Skip to the answer",
    nav: {
      answer: "Answer",
      years: "Years",
      index: "Index",
      method: "Method",
      meaning: "Meaning",
      sources: "Sources",
    },
    kicker: "Mini research project · 31 editions",
    titleA: "Who wins",
    titleB: "in Asian basketball?",
    deck: "Title concentration and competitive balance at the FIBA Asia Cup, 1960–2025.",
    byline: "Aldiyar Akanov",
    questionLabel: "Question",
    question:
      "How concentrated are titles at the FIBA Asia Cup, and did the 2017 inclusion of Oceania change competitive balance?",
    aimLabel: "Aim",
    aim: "Record the champions of all 31 editions, compute the HHI for four eras, and read the result through competitive-balance theory.",
    answerLabel: "Short answer",
    answer:
      "Concentration is high and cyclical: overall HHI 0.32, with 16 of 31 titles to China. Oceania’s 2017 entry did not improve balance — Australia won three editions out of three. The centre of power moved. It did not spread.",
    copyAnswer: "Copy the answer",
    copied: "Copied",
    statHhi: "0.32",
    statHhiLabel: "overall HHI of titles, 31 editions",
    statChina: "16 / 31",
    statChinaLabel: "titles won by China, all of them 1975–2015",
    statAus: "18–0",
    statAusLabel: "Australia’s Asia Cup run, 3 titles since 2017",
    yearsTitle: "Who took the cup",
    yearsLead:
      "Six teams have won it. Thirty-four have played in it. Tap a year or an era. The ribbon records the champion, not a made-up score.",
    allEras: "All eras",
    allTeams: "All",
    tapYear: "Tap a year to read why it matters to the question.",
    editionsNote:
      "The ribbon is editions, not every calendar year. Through 2015 the cup was biennial. From 2017 it is a stand-alone FIBA Asia Cup.",
    championWord: "Champion",
    finalWord: "Final",
    indexTitle: "How concentrated that is",
    indexLead:
      "HHI is the sum of squared title shares. Near 1/N means balance; 1.00 means one winner. Split evenly among the six champions, HHI would be 0.17. The actual 0.32 is nearly twice as tight: only 3.13 effective champions.",
    colEra: "Era",
    colEditions: "Editions",
    colChampions: "Champions",
    colHhi: "HHI",
    colLeader: "Leader share",
    colEff: "Eff. champions",
    allEra: "All, 1960–2025",
    hhiCaption: "HHI of titles. 1.00 means one team wins everything. Bar colour is the era’s leader.",
    medalTitle: "A title is not the whole depth",
    medalLead:
      "Korea has only 2 golds, but 11 silvers and 12 bronzes. Japan has 2, 5 and 7. Titles alone hide who keeps finishing next to the top.",
    gold: "Gold",
    silver: "Silver",
    bronze: "Bronze",
    eraName: {
      founding: "1960–1973",
      china: "1975–2005",
      west: "2007–2015",
      oceania: "2017–2025",
    },
    eraShort: {
      founding: "60–73",
      china: "75–05",
      west: "07–15",
      oceania: "17–25",
    },
    eraBody: {
      founding:
        "Seven editions, three champions. The Philippines take four. HHI 0.43: already tight, not yet a monopoly. Japan and Korea are already on the roll.",
      china:
        "Sixteen editions. China 14, plus one each for the Philippines (1985) and Korea (1997). HHI 0.77, leader share 88%. The peak of the series.",
      west:
        "Five editions, two champions. Iran 3, China 2. HHI falls to 0.52. Finals often pair a West Asian side with an East Asian one.",
      oceania:
        "Three editions, one champion. Australia 3 of 3, HHI 1.00. Oceania moved the centre of power; it did not share the titles. The study records Australia at 18–0.",
    },
    threeKicker: "Beside the sample, not in it",
    threeTitle: "3×3 is a different game",
    threeBody:
      "This study is the full-court FIBA Asia Cup. Outdoor 3×3 is a separate FIBA competition, and its titles are not in the count. The picture is atmosphere, not an archival match photo.",
    methodTitle: "How it was counted",
    methodLead:
      "A quantitative reading of the whole population: every edition, no sample, no interviews. Eras are cut on a structural break, not a round number.",
    rows: [
      {
        k: "Approach",
        v: "Quantitative, descriptive, longitudinal analysis of secondary data. No human participants.",
      },
      {
        k: "Why",
        v: "Outcomes are title counts, so eras can be compared with one index.",
      },
      {
        k: "Data",
        v: "Champions of all 31 editions, 1960–2025, from published tournament records.",
      },
      {
        k: "Population",
        v: "Every edition. Eras: 1960–73; 1975–2005, China debuts; 2007–15, the West Asian rise; 2017–25, Oceania joins.",
      },
      {
        k: "Instruments",
        v: "HHI = sum of squared title shares; the leader’s share; effective champions = 1/HHI.",
      },
      {
        k: "Procedure",
        v: "List the champions, count titles per era, compute the indices, then chart them.",
      },
      {
        k: "Ethics",
        v: "Public data only. Sources credited. Nothing invented or altered.",
      },
    ],
    labTitle: "Turn the index yourself",
    labLead:
      "A teaching bench, not new data. Take a title from one team and give it to another. The total stays 31.",
    labHint: "Minus first, then plus on a different team.",
    labReset: "Restore the record",
    labNow: "Now",
    labActual: "In the study",
    labPool: "In hand",
    labGive: "Take a title",
    labTake: "Give a title",
    meaningTitle: "What follows",
    bullets: [
      "No steady trend. Concentration peaks in the China era (1975–2005), eases in 2007–2015 when Iran wins three titles, then hits 1.00 after 2017.",
      "The hypothesis holds in the surprising direction: Oceania did not spread success. Australia won every edition, so the centre of power moved.",
      "That matches Truyens et al. and SAGE Open (2024): concentration persists even when more nations take part.",
    ],
    limitTitle: "Where the study is thin",
    limits: [
      "The last era has only three editions. One winner produces an HHI of 1.00 by arithmetic.",
      "China did not always field its strongest team, for example in 2007.",
      "Titles ignore medal depth. The data are secondary.",
    ],
    closeTitle: "Answer",
    closeBody:
      "Title concentration at the FIBA Asia Cup is high and cyclical (overall HHI 0.32; 16 of 31 titles to China). The 2017 entry of Oceania did not improve balance: Australia leads with 3 of 3 titles.",
    recs: "Judge balance with medals and top-four places, not titles alone. Later work should add game margins and a dynamic stability measure.",
    sourcesTitle: "Sources",
    sourcesNote:
      "The bibliography follows the poster. Where the poster still said to add an author, that gap is kept — it is not filled in.",
    illus:
      "Court and 3×3 frames are generated illustrations, not photos of particular matches or players. They are not evidence.",
    footer: "Who Wins · a mini study of the FIBA Asia Cup",
    heroAlt: "Illustration: a layup in a single pool of arena light, no numbers and no identifiable face.",
    threeAlt: "Illustration: an outdoor 3×3 moment at dusk, faces unreadable.",
    courtAlt: "Illustration: an empty court and one pool of warm light.",
    tunnelAlt: "Illustration: player silhouettes leaving a lit court for the tunnel.",
  },
};
