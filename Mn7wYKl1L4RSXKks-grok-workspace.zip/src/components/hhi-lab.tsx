import { useMemo, useState } from "react";
import {
  EDITIONS,
  TEAM_IDS,
  TEAMS,
  countsFor,
  emptyCounts,
  formatEff,
  formatHhi,
  hhi,
  type TeamId,
} from "@/data/cup";
import type { Lang, Ui } from "@/copy/ui";

type Props = { lang: Lang; text: Ui };

export function HhiLab({ lang, text }: Props) {
  const actual = useMemo(() => countsFor(EDITIONS), []);
  const [counts, setCounts] = useState(actual);
  const [pool, setPool] = useState(0);

  const index = hhi(TEAM_IDS.map((id) => counts[id]));
  const actualIndex = hhi(TEAM_IDS.map((id) => actual[id]));

  const take = (id: TeamId) => {
    if (counts[id] <= 0) return;
    setCounts({ ...counts, [id]: counts[id] - 1 });
    setPool(pool + 1);
  };

  const give = (id: TeamId) => {
    if (pool <= 0) return;
    setCounts({ ...counts, [id]: counts[id] + 1 });
    setPool(pool - 1);
  };

  const reset = () => {
    setCounts({ ...emptyCounts(), ...actual });
    setPool(0);
  };

  return (
    <div className="rounded-xl border border-line bg-court p-4 text-fg md:p-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium tracking-widest text-gold uppercase">{text.labNow}</p>
          <p className="font-display text-5xl leading-none text-fg tabular-nums">{formatHhi(index)}</p>
          <p className="mt-2 text-sm text-muted">
            1/HHI = {formatEff(index > 0 ? 1 / index : 0)} · {text.labActual} {formatHhi(actualIndex)} · {text.labPool}{" "}
            {pool}
          </p>
        </div>
        <button
          type="button"
          onClick={reset}
          className="h-11 rounded-full border border-line px-4 text-sm font-medium text-fg"
        >
          {text.labReset}
        </button>
      </div>
      <p className="mt-4 text-sm leading-relaxed text-muted">{text.labHint}</p>
      <ul className="mt-4 grid gap-2">
        {TEAM_IDS.map((id) => (
          <li key={id} className="flex items-center gap-3 rounded-xl bg-panel px-3 py-2">
            <span className={`size-3 shrink-0 rounded-full ${TEAMS[id].swatch}`} aria-hidden />
            <span className="min-w-0 flex-1 text-sm text-fg">
              {lang === "ru" ? TEAMS[id].ru : TEAMS[id].en}
            </span>
            <span className="w-8 text-right font-display text-xl tabular-nums">{counts[id]}</span>
            <button
              type="button"
              aria-label={`${text.labGive}: ${TEAMS[id].en}`}
              disabled={counts[id] <= 0}
              onClick={() => take(id)}
              className="grid size-11 place-items-center rounded-full border border-line text-lg disabled:opacity-30"
            >
              −
            </button>
            <button
              type="button"
              aria-label={`${text.labTake}: ${TEAMS[id].en}`}
              disabled={pool <= 0}
              onClick={() => give(id)}
              className="grid size-11 place-items-center rounded-full bg-gold text-lg text-ink disabled:opacity-30"
            >
              +
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
