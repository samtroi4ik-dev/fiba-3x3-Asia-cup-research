import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Lang } from "@/copy/ui";

type LangValue = { lang: Lang; setLang: (lang: Lang) => void };

const LangContext = createContext<LangValue>({ lang: "ru", setLang: () => undefined });

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("ru");

  useEffect(() => {
    const saved = localStorage.getItem("ww-lang");
    if (saved === "en" || saved === "ru") setLangState(saved);
    document.documentElement.lang = saved === "en" ? "en" : "ru";
  }, []);

  const setLang = (next: Lang) => {
    setLangState(next);
    localStorage.setItem("ww-lang", next);
    document.documentElement.lang = next;
  };

  return <LangContext.Provider value={{ lang, setLang }}>{children}</LangContext.Provider>;
}

export function useLang() {
  return useContext(LangContext);
}
