import { useState } from "react";
import { Check, Copy } from "lucide-react";
import { ERAS, type EraId, type TeamId } from "@/data/cup";
import { REFERENCES } from "@/data/cup";
import { ui } from "@/copy/ui";
import { LangProvider, useLang } from "@/components/lang";
import { Timeline } from "@/components/timeline";
import { Charts } from "@/components/charts";
import { HhiLab } from "@/components/hhi-lab";

export function ResearchPage() {
  return (
    <LangProvider>
      <Page />
    </LangProvider>
  );
}

function Page() {
  const { lang, setLang } = useLang();
  const text = ui[lang];
  const [era, setEra] = useState<EraId | "all">("all");
  const [team, setTeam] = useState<TeamId | "all">("all");
  const [year, setYear] = useState<number | null>(1975);
  const [copied, setCopied] = useState(false);

  const copyAnswer = async () => {
    try {
      await navigator.clipboard.writeText(text.answer);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="min-h-screen bg-ink text-fg">
      <a
        href="#answer"
        className="sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-30 focus:rounded-full focus:bg-gold focus:px-4 focus:py-3 focus:text-ink"
      >
        {text.skip}
      </a>
      <header className="sticky top-0 z-20 border-b border-line bg-ink/95 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center gap-3 px-4 py-2">
          <a href="#top" className="font-display text-lg text-fg">
            Who Wins
          </a>
          <nav className="flex min-w-0 flex-1 gap-1 overflow-x-auto" aria-label="Sections">
            <NavLink href="#answer">{text.nav.answer}</NavLink>
            <NavLink href="#years">{text.nav.years}</NavLink>
            <NavLink href="#index">{text.nav.index}</NavLink>
            <NavLink href="#method">{text.nav.method}</NavLink>
            <NavLink href="#meaning">{text.nav.meaning}</NavLink>
            <NavLink href="#sources">{text.nav.sources}</NavLink>
          </nav>
          <div className="flex shrink-0 rounded-full border border-line p-1">
            <LangButton current={lang} id="ru" onPick={setLang}>
              RU
            </LangButton>
            <LangButton current={lang} id="en" onPick={setLang}>
              EN
            </LangButton>
          </div>
        </div>
      </header>

      <main id="top">
        <section className="relative min-h-screen">
          <img
            src="/images/arena.jpg"
            alt={text.heroAlt}
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-ink/45" />
          <div className="absolute inset-x-0 bottom-0 h-2/3 bg-ink/80" />
          <div className="relative mx-auto flex min-h-screen max-w-5xl flex-col justify-end px-5 pt-24 pb-12">
            <p className="text-xs font-medium tracking-widest text-gold uppercase">{text.kicker}</p>
            <h1 className="mt-3 max-w-3xl font-display text-5xl leading-none text-fg md:text-7xl">
              {text.titleA}
              <span className="block italic">{text.titleB}</span>
            </h1>
            <p className="mt-4 max-w-xl text-lg leading-relaxed text-fg">{text.deck}</p>
            <p className="mt-6 text-sm text-muted">{text.byline}</p>
          </div>
        </section>

        <section id="answer" className="scroll-mt-16 border-t border-line">
          <div className="mx-auto grid max-w-5xl gap-6 px-5 py-14 md:grid-cols-5">
            <div className="md:col-span-3">
              <p className="text-xs font-medium tracking-widest text-gold uppercase">{text.questionLabel}</p>
              <p className="mt-3 font-display text-3xl leading-tight text-fg">{text.question}</p>
              <p className="mt-4 text-sm leading-relaxed text-muted">
                <span className="font-medium text-fg">{text.aimLabel}. </span>
                {text.aim}
              </p>
            </div>
            <div className="rounded-xl border border-gold bg-panel p-5 md:col-span-2">
              <p className="text-xs font-medium tracking-widest text-gold uppercase">{text.answerLabel}</p>
              <p className="mt-3 text-base leading-relaxed text-fg">{text.answer}</p>
              <button
                type="button"
                onClick={copyAnswer}
                className="mt-5 inline-flex h-11 items-center gap-2 rounded-full bg-gold px-4 text-sm font-medium text-ink"
              >
                {copied ? <Check className="size-4" aria-hidden /> : <Copy className="size-4" aria-hidden />}
                {copied ? text.copied : text.copyAnswer}
              </button>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl gap-3 px-5 pb-14 md:grid-cols-3">
            <Stat value={text.statHhi} label={text.statHhiLabel} />
            <Stat value={text.statChina} label={text.statChinaLabel} />
            <Stat value={text.statAus} label={text.statAusLabel} />
          </div>
        </section>

        <section id="years" className="scroll-mt-16 border-t border-line bg-court">
          <div className="mx-auto max-w-5xl px-5 py-14">
            <SectionTitle title={text.yearsTitle} lead={text.yearsLead} />
            <div className="mt-8">
              <Timeline
                lang={lang}
                text={text}
                era={era}
                team={team}
                year={year}
                onEra={setEra}
                onTeam={setTeam}
                onYear={setYear}
              />
            </div>
            <div className="mt-8 grid gap-3 md:grid-cols-2">
              {ERAS.map((row) => (
                <button
                  key={row.id}
                  type="button"
                  onClick={() => setEra(row.id)}
                  aria-pressed={era === row.id}
                  className={`rounded-xl border p-4 text-left ${
                    era === row.id ? "border-gold bg-panel" : "border-line bg-ink"
                  }`}
                >
                  <p className="text-xs font-medium tracking-widest text-gold uppercase">{text.eraName[row.id]}</p>
                  <p className="mt-2 text-sm leading-relaxed text-fg">{text.eraBody[row.id]}</p>
                </button>
              ))}
            </div>
          </div>
        </section>

        <section id="index" className="scroll-mt-16 border-t border-line">
          <div className="mx-auto max-w-5xl px-5 py-14">
            <SectionTitle title={text.indexTitle} lead={text.indexLead} />
            <div className="mt-8">
              <Charts text={text} langRu={lang === "ru"} era={era} onEra={setEra} />
            </div>
          </div>
        </section>

        <section className="border-t border-line">
          <div className="mx-auto grid max-w-5xl items-center gap-6 px-5 py-14 md:grid-cols-2">
            <img src="/images/three.jpg" alt={text.threeAlt} className="aspect-3/2 w-full rounded-xl object-cover" />
            <div>
              <p className="text-xs font-medium tracking-widest text-gold uppercase">{text.threeKicker}</p>
              <h2 className="mt-2 font-display text-4xl text-fg">{text.threeTitle}</h2>
              <p className="mt-3 text-base leading-relaxed text-muted">{text.threeBody}</p>
            </div>
          </div>
        </section>

        <section id="method" className="scroll-mt-16 border-t border-line bg-paper text-ink">
          <div className="mx-auto grid max-w-5xl gap-8 px-5 py-14 md:grid-cols-2">
            <div>
              <h2 className="font-display text-4xl">{text.methodTitle}</h2>
              <p className="mt-3 text-base leading-relaxed text-ink/75">{text.methodLead}</p>
              <img
                src="/images/court.jpg"
                alt={text.courtAlt}
                className="mt-6 aspect-video w-full rounded-xl object-cover"
              />
              <dl className="mt-6 divide-y divide-ink/15">
                {text.rows.map((row) => (
                  <div key={row.k} className="grid gap-1 py-3 sm:grid-cols-3">
                    <dt className="text-sm font-medium">{row.k}</dt>
                    <dd className="text-sm leading-relaxed text-ink/75 sm:col-span-2">{row.v}</dd>
                  </div>
                ))}
              </dl>
            </div>
            <div>
              <h3 className="font-display text-3xl">{text.labTitle}</h3>
              <p className="mt-2 mb-4 text-sm leading-relaxed text-ink/75">{text.labLead}</p>
              <HhiLab lang={lang} text={text} />
            </div>
          </div>
        </section>

        <section id="meaning" className="scroll-mt-16 border-t border-line">
          <div className="mx-auto grid max-w-5xl gap-8 px-5 py-14 md:grid-cols-5">
            <div className="md:col-span-3">
              <h2 className="font-display text-4xl text-fg">{text.meaningTitle}</h2>
              <ul className="mt-6 grid gap-4">
                {text.bullets.map((bullet) => (
                  <li key={bullet} className="border-l-2 border-gold pl-4 text-base leading-relaxed text-fg">
                    {bullet}
                  </li>
                ))}
              </ul>
              <h3 className="mt-10 font-display text-2xl text-fg">{text.limitTitle}</h3>
              <ul className="mt-4 grid gap-3">
                {text.limits.map((limit) => (
                  <li key={limit} className="text-sm leading-relaxed text-muted">
                    {limit}
                  </li>
                ))}
              </ul>
            </div>
            <div className="md:col-span-2">
              <img src="/images/tunnel.jpg" alt={text.tunnelAlt} className="aspect-3/2 w-full rounded-xl object-cover" />
              <div className="mt-4 rounded-xl bg-gold p-5 text-ink">
                <h3 className="font-display text-2xl">{text.closeTitle}</h3>
                <p className="mt-3 text-sm leading-relaxed">{text.closeBody}</p>
                <p className="mt-3 text-sm leading-relaxed">{text.recs}</p>
              </div>
            </div>
          </div>
        </section>

        <section id="sources" className="scroll-mt-16 border-t border-line bg-court">
          <div className="mx-auto max-w-5xl px-5 py-14">
            <h2 className="font-display text-4xl text-fg">{text.sourcesTitle}</h2>
            <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted">{text.sourcesNote}</p>
            <ol className="mt-6 grid gap-3">
              {REFERENCES.map((ref) => (
                <li key={ref.text} className="text-sm leading-relaxed text-fg">
                  {ref.href ? (
                    <a href={ref.href} className="underline decoration-line underline-offset-4">
                      {ref.text}
                    </a>
                  ) : (
                    ref.text
                  )}
                </li>
              ))}
            </ol>
            <p className="mt-8 max-w-2xl text-sm leading-relaxed text-muted">{text.illus}</p>
          </div>
        </section>
      </main>
      <footer className="border-t border-line px-5 py-8 text-center text-sm text-muted">{text.footer}</footer>
    </div>
  );
}

function NavLink({ href, children }: { href: string; children: string }) {
  return (
    <a href={href} className="inline-flex h-11 shrink-0 items-center px-2 text-sm text-muted">
      {children}
    </a>
  );
}

function LangButton({
  current,
  id,
  onPick,
  children,
}: {
  current: "ru" | "en";
  id: "ru" | "en";
  onPick: (lang: "ru" | "en") => void;
  children: string;
}) {
  const on = current === id;
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={() => onPick(id)}
      className={`h-9 rounded-full px-3 text-sm font-medium ${on ? "bg-gold text-ink" : "text-muted"}`}
    >
      {children}
    </button>
  );
}

function Stat({ value, label }: { value: string; label: string }) {
  return (
    <div className="rounded-xl border border-line bg-court px-4 py-4">
      <p className="font-display text-4xl text-gold tabular-nums">{value}</p>
      <p className="mt-2 text-sm leading-relaxed text-muted">{label}</p>
    </div>
  );
}

function SectionTitle({ title, lead }: { title: string; lead: string }) {
  return (
    <div className="max-w-2xl">
      <h2 className="font-display text-4xl text-fg">{title}</h2>
      <p className="mt-3 text-base leading-relaxed text-muted">{lead}</p>
    </div>
  );
}
