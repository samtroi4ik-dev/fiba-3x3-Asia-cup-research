import { useEffect, useState } from "react";
import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import {
  EDITIONS,
  ERAS,
  MEDALS,
  TEAMS,
  formatEff,
  formatHhi,
  formatShare,
  summarize,
  type EraId,
  type TeamId,
} from "@/data/cup";
import type { Ui } from "@/copy/ui";

const LEADER_FILL: Record<TeamId, string> = {
  CHN: "var(--color-team-chn)",
  PHI: "var(--color-team-phi)",
  IRI: "var(--color-team-iri)",
  AUS: "var(--color-team-aus)",
  KOR: "var(--color-team-kor)",
  JPN: "var(--color-team-jpn)",
};

type Props = {
  text: Ui;
  langRu: boolean;
  era: EraId | "all";
  onEra: (era: EraId | "all") => void;
};

export function Charts({ text, langRu, era, onEra }: Props) {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);

  const rows = [
    ...ERAS.map((row) => {
      const summary = summarize(EDITIONS.filter((edition) => edition.era === row.id));
      return {
        id: row.id as EraId | "all",
        label: text.eraShort[row.id],
        hhi: Number(summary.hhi.toFixed(2)),
        fill: LEADER_FILL[summary.leader],
      };
    }),
    {
      id: "all" as const,
      label: langRu ? "все" : "all",
      hhi: Number(summarize(EDITIONS).hhi.toFixed(2)),
      fill: "var(--color-paper)",
    },
  ];

  const medals = MEDALS.map((row) => ({
    code: row.team,
    name: langRu ? TEAMS[row.team].ru : TEAMS[row.team].en,
    g: row.g,
    s: row.s,
    b: row.b,
  }));

  const tableEras = ERAS.map((row) => ({
    id: row.id,
    label: text.eraName[row.id],
    summary: summarize(EDITIONS.filter((edition) => edition.era === row.id)),
  }));
  const all = summarize(EDITIONS);

  return (
    <div className="grid gap-8">
      <div className="overflow-x-auto rounded-xl border border-line">
        <table className="w-full min-w-[36rem] text-left text-sm">
          <thead className="bg-court text-muted">
            <tr>
              <th className="px-3 py-3 font-medium">{text.colEra}</th>
              <th className="px-3 py-3 font-medium">{text.colEditions}</th>
              <th className="px-3 py-3 font-medium">{text.colChampions}</th>
              <th className="px-3 py-3 font-medium">{text.colHhi}</th>
              <th className="px-3 py-3 font-medium">{text.colLeader}</th>
              <th className="px-3 py-3 font-medium">{text.colEff}</th>
            </tr>
          </thead>
          <tbody>
            {tableEras.map((row) => (
              <tr key={row.id} className={era === row.id ? "bg-panel" : "bg-ink"}>
                <td className="border-t border-line px-3 py-3">
                  <button type="button" className="font-medium text-fg" onClick={() => onEra(row.id)}>
                    {row.label}
                  </button>
                </td>
                <td className="border-t border-line px-3 py-3 tabular-nums">{row.summary.total}</td>
                <td className="border-t border-line px-3 py-3 tabular-nums">{row.summary.champions}</td>
                <td className="border-t border-line px-3 py-3 font-display text-lg tabular-nums text-gold">
                  {formatHhi(row.summary.hhi)}
                </td>
                <td className="border-t border-line px-3 py-3">
                  {formatShare(row.summary.leaderShare)}{" "}
                  <span className="text-muted">({row.summary.leader})</span>
                </td>
                <td className="border-t border-line px-3 py-3 tabular-nums">{formatEff(row.summary.eff)}</td>
              </tr>
            ))}
            <tr className={era === "all" ? "bg-panel" : "bg-ink"}>
              <td className="border-t border-line px-3 py-3 font-medium">{text.allEra}</td>
              <td className="border-t border-line px-3 py-3 tabular-nums">{all.total}</td>
              <td className="border-t border-line px-3 py-3 tabular-nums">{all.champions}</td>
              <td className="border-t border-line px-3 py-3 font-display text-lg tabular-nums text-gold">
                {formatHhi(all.hhi)}
              </td>
              <td className="border-t border-line px-3 py-3">
                {formatShare(all.leaderShare)} <span className="text-muted">({all.leader})</span>
              </td>
              <td className="border-t border-line px-3 py-3 tabular-nums">{formatEff(all.eff)}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="rounded-xl border border-line bg-court p-4">
        <div className="h-72">
          {ready ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={rows} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
                <XAxis
                  dataKey="label"
                  tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  domain={[0, 1]}
                  ticks={[0, 0.25, 0.5, 0.75, 1]}
                  tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                  width={36}
                />
                <Tooltip
                  cursor={{ fill: "var(--color-panel)" }}
                  contentStyle={{
                    background: "var(--color-panel)",
                    border: "1px solid var(--color-line)",
                    borderRadius: 12,
                    color: "var(--color-fg)",
                  }}
                  formatter={(value) => [typeof value === "number" ? value.toFixed(2) : value, "HHI"]}
                />
                <Bar
                  dataKey="hhi"
                  radius={[8, 8, 0, 0]}
                  onClick={(state) => {
                    const id = (state as { id?: EraId | "all" }).id;
                    if (id) onEra(id);
                  }}
                >
                  {rows.map((row) => (
                    <Cell
                      key={row.id}
                      fill={row.fill}
                      stroke={era === row.id ? "var(--color-gold)" : "transparent"}
                      strokeWidth={era === row.id ? 2 : 0}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full rounded-lg bg-panel" />
          )}
        </div>
        <p className="mt-2 text-sm leading-relaxed text-muted">{text.hhiCaption}</p>
      </div>

      <div>
        <h3 className="font-display text-3xl text-fg">{text.medalTitle}</h3>
        <p className="mt-2 max-w-2xl text-base leading-relaxed text-muted">{text.medalLead}</p>
        <div className="mt-4 flex gap-4 text-sm text-muted">
          <span className="inline-flex items-center gap-2">
            <i className="inline-block size-2.5 rounded-full bg-gold" aria-hidden />
            {text.gold}
          </span>
          <span className="inline-flex items-center gap-2">
            <i className="inline-block size-2.5 rounded-full bg-silver" aria-hidden />
            {text.silver}
          </span>
          <span className="inline-flex items-center gap-2">
            <i className="inline-block size-2.5 rounded-full bg-bronze" aria-hidden />
            {text.bronze}
          </span>
        </div>
        <div className="mt-4 h-72 rounded-xl border border-line bg-court p-4">
          {ready ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={medals} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
                <XAxis
                  dataKey="code"
                  tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  allowDecimals={false}
                  tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                  width={28}
                />
                <Tooltip
                  cursor={{ fill: "var(--color-panel)" }}
                  contentStyle={{
                    background: "var(--color-panel)",
                    border: "1px solid var(--color-line)",
                    borderRadius: 12,
                    color: "var(--color-fg)",
                  }}
                />
                <Bar dataKey="b" stackId="medals" fill="var(--color-bronze)" name={text.bronze} />
                <Bar dataKey="s" stackId="medals" fill="var(--color-silver)" name={text.silver} />
                <Bar dataKey="g" stackId="medals" fill="var(--color-gold)" name={text.gold} radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full rounded-lg bg-panel" />
          )}
        </div>
      </div>
    </div>
  );
}
