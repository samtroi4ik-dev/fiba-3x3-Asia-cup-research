import type { ReactNode } from "react";
import {
  EDITIONS,
  ERAS,
  FINALS,
  NOTES,
  TEAMS,
  TEAM_IDS,
  type EraId,
  type TeamId,
} from "@/data/cup";
import type { Lang, Ui } from "@/copy/ui";

type Props = {
  lang: Lang;
  text: Ui;
  era: EraId | "all";
  team: TeamId | "all";
  year: number | null;
  onEra: (era: EraId | "all") => void;
  onTeam: (team: TeamId | "all") => void;
  onYear: (year: number) => void;
};

function matches(editionEra: EraId, editionTeam: TeamId, era: EraId | "all", team: TeamId | "all") {
  return (era === "all" || editionEra === era) && (team === "all" || editionTeam === team);
}

export function Timeline({ lang, text, era, team, year, onEra, onTeam, onYear }: Props) {
  const selected = EDITIONS.find((edition) => edition.year === year) ?? null;
  const note = selected ? NOTES[selected.year] : undefined;
  const final = selected ? FINALS.find((row) => row.year === selected.year) : undefined;
  const eraMeta = selected ? ERAS.find((row) => row.id === selected.era) : undefined;

  return (
    <div>
      <div className="flex gap-2 overflow-x-auto pb-3">
        <FilterChip pressed={era === "all"} onClick={() => onEra("all")}>
          {text.allEras}
        </FilterChip>
        {ERAS.map((row) => (
          <FilterChip key={row.id} pressed={era === row.id} onClick={() => onEra(row.id)}>
            {text.eraName[row.id]}
          </FilterChip>
        ))}
      </div>
      <div className="mt-2 flex gap-2 overflow-x-auto pb-4">
        <FilterChip pressed={team === "all"} onClick={() => onTeam("all")}>
          {text.allTeams}
        </FilterChip>
        {TEAM_IDS.map((id) => (
          <FilterChip key={id} pressed={team === id} onClick={() => onTeam(id)}>
            <span className={`inline-block size-2.5 rounded-full ${TEAMS[id].swatch}`} aria-hidden />
            {lang === "ru" ? TEAMS[id].ru : TEAMS[id].en}
          </FilterChip>
        ))}
      </div>

      <div className="flex gap-2 overflow-x-auto pb-2 snap-x snap-mandatory">
        {EDITIONS.map((edition) => {
          const on = matches(edition.era, edition.team, era, team);
          const active = year === edition.year;
          return (
            <button
              key={edition.year}
              type="button"
              onClick={() => onYear(edition.year)}
              aria-pressed={active}
              className={`snap-start flex h-24 w-20 shrink-0 flex-col justify-between rounded-xl border px-2 py-2 text-left transition ${
                active
                  ? "border-gold bg-panel"
                  : on
                    ? "border-line bg-court"
                    : "border-line bg-ink opacity-35"
              }`}
            >
              <span className={`h-1.5 w-8 rounded-full ${TEAMS[edition.team].swatch}`} aria-hidden />
              <span>
                <span className="block font-display text-lg leading-none text-fg">{edition.team}</span>
                <span className="mt-1 block text-xs text-muted">{edition.year}</span>
              </span>
            </button>
          );
        })}
      </div>
      <p className="mt-3 text-sm leading-relaxed text-muted">{text.editionsNote}</p>

      <div className="mt-4 rounded-xl border border-line bg-panel p-4">
        {selected && eraMeta ? (
          <>
            <p className="text-xs font-medium tracking-widest text-gold uppercase">
              {text.eraName[selected.era]}
            </p>
            <h3 className="mt-1 font-display text-3xl text-fg">
              {selected.year}
              <span className="ml-3 text-xl text-muted">
                {lang === "ru" ? TEAMS[selected.team].ru : TEAMS[selected.team].en}
              </span>
            </h3>
            <p className="mt-3 max-w-2xl text-base leading-relaxed text-fg">
              {note
                ? note[lang]
                : lang === "ru"
                  ? `${TEAMS[selected.team].ru} побеждает в ${selected.year}. Окно «${text.eraName[selected.era]}».`
                  : `${TEAMS[selected.team].en} wins ${selected.year}, inside the ${text.eraName[selected.era]} window.`}
            </p>
            {final ? (
              <p className="mt-3 text-sm text-muted">
                {text.finalWord}: {lang === "ru" ? TEAMS[selected.team].ru : TEAMS[selected.team].en}
                {" – "}
                {lang === "ru" ? final.runnerRu : final.runnerEn}
              </p>
            ) : null}
          </>
        ) : (
          <p className="text-base leading-relaxed text-muted">{text.tapYear}</p>
        )}
      </div>
    </div>
  );
}

function FilterChip({
  pressed,
  onClick,
  children,
}: {
  pressed: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-pressed={pressed}
      onClick={onClick}
      className={`inline-flex h-11 shrink-0 items-center gap-2 rounded-full border px-4 text-sm font-medium ${
        pressed ? "border-gold bg-gold text-ink" : "border-line bg-court text-fg"
      }`}
    >
      {children}
    </button>
  );
}
