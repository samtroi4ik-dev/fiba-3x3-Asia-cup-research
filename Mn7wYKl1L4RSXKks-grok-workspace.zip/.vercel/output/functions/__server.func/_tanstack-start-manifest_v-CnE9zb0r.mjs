//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CnE9zb0r.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BgHprGDg.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BgHprGDg.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-0u3Kko7z.js"]
	}
} });
//#endregion
export { tsrStartManifest };
