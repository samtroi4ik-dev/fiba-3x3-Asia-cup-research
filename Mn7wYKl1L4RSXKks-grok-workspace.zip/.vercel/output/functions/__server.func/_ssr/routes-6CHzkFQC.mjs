import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Copy, r as Check } from "../_libs/lucide-react.mjs";
import { a as Cell, i as Bar, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-6CHzkFQC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TEAM_IDS = [
	"CHN",
	"PHI",
	"IRI",
	"AUS",
	"KOR",
	"JPN"
];
var TEAMS = {
	CHN: {
		en: "China",
		ru: "Китай",
		swatch: "bg-team-chn"
	},
	PHI: {
		en: "Philippines",
		ru: "Филиппины",
		swatch: "bg-team-phi"
	},
	IRI: {
		en: "Iran",
		ru: "Иран",
		swatch: "bg-team-iri"
	},
	AUS: {
		en: "Australia",
		ru: "Австралия",
		swatch: "bg-team-aus"
	},
	KOR: {
		en: "South Korea",
		ru: "Южная Корея",
		swatch: "bg-team-kor"
	},
	JPN: {
		en: "Japan",
		ru: "Япония",
		swatch: "bg-team-jpn"
	}
};
var ERAS = [
	{
		id: "founding",
		from: 1960,
		to: 1973
	},
	{
		id: "china",
		from: 1975,
		to: 2005
	},
	{
		id: "west",
		from: 2007,
		to: 2015
	},
	{
		id: "oceania",
		from: 2017,
		to: 2025
	}
];
var EDITIONS = [
	[
		1960,
		"PHI",
		"founding"
	],
	[
		1963,
		"PHI",
		"founding"
	],
	[
		1965,
		"JPN",
		"founding"
	],
	[
		1967,
		"PHI",
		"founding"
	],
	[
		1969,
		"KOR",
		"founding"
	],
	[
		1971,
		"JPN",
		"founding"
	],
	[
		1973,
		"PHI",
		"founding"
	],
	[
		1975,
		"CHN",
		"china"
	],
	[
		1977,
		"CHN",
		"china"
	],
	[
		1979,
		"CHN",
		"china"
	],
	[
		1981,
		"CHN",
		"china"
	],
	[
		1983,
		"CHN",
		"china"
	],
	[
		1985,
		"PHI",
		"china"
	],
	[
		1987,
		"CHN",
		"china"
	],
	[
		1989,
		"CHN",
		"china"
	],
	[
		1991,
		"CHN",
		"china"
	],
	[
		1993,
		"CHN",
		"china"
	],
	[
		1995,
		"CHN",
		"china"
	],
	[
		1997,
		"KOR",
		"china"
	],
	[
		1999,
		"CHN",
		"china"
	],
	[
		2001,
		"CHN",
		"china"
	],
	[
		2003,
		"CHN",
		"china"
	],
	[
		2005,
		"CHN",
		"china"
	],
	[
		2007,
		"IRI",
		"west"
	],
	[
		2009,
		"IRI",
		"west"
	],
	[
		2011,
		"CHN",
		"west"
	],
	[
		2013,
		"IRI",
		"west"
	],
	[
		2015,
		"CHN",
		"west"
	],
	[
		2017,
		"AUS",
		"oceania"
	],
	[
		2022,
		"AUS",
		"oceania"
	],
	[
		2025,
		"AUS",
		"oceania"
	]
].map(([year, team, era]) => ({
	year,
	team,
	era
}));
var MEDALS = [
	{
		team: "CHN",
		g: 16,
		s: 2,
		b: 2
	},
	{
		team: "PHI",
		g: 5,
		s: 4,
		b: 1
	},
	{
		team: "IRI",
		g: 3,
		s: 1,
		b: 2
	},
	{
		team: "AUS",
		g: 3,
		s: 0,
		b: 0
	},
	{
		team: "KOR",
		g: 2,
		s: 11,
		b: 12
	},
	{
		team: "JPN",
		g: 2,
		s: 5,
		b: 7
	}
];
/** Runner-up only where a published final was checked. Not used in the HHI. */
var FINALS = [
	{
		year: 2007,
		runnerEn: "Lebanon",
		runnerRu: "Ливан"
	},
	{
		year: 2009,
		runnerEn: "China",
		runnerRu: "Китай"
	},
	{
		year: 2011,
		runnerEn: "Jordan",
		runnerRu: "Иордания"
	},
	{
		year: 2013,
		runnerEn: "Philippines",
		runnerRu: "Филиппины"
	},
	{
		year: 2015,
		runnerEn: "Philippines",
		runnerRu: "Филиппины"
	},
	{
		year: 2017,
		runnerEn: "Iran",
		runnerRu: "Иран"
	},
	{
		year: 2022,
		runnerEn: "Lebanon",
		runnerRu: "Ливан"
	},
	{
		year: 2025,
		runnerEn: "China",
		runnerRu: "Китай"
	}
];
var NOTES = {
	1960: {
		en: "First edition, in Manila. The Asian Championship begins, and the Philippines win it.",
		ru: "Первый турнир, Манила. С него начинается чемпионат Азии, и его берут Филиппины."
	},
	1975: {
		en: "China debuts and wins. The study uses this as the break that opens the China era.",
		ru: "Дебют и первая победа Китая. В работе это граница, с которой открывается эра Китая."
	},
	1985: {
		en: "The Philippines break a long Chinese run — the only other champion between 1975 and 1995.",
		ru: "Филиппины прерывают длинную серию Китая — единственный другой чемпион между 1975 и 1995."
	},
	1997: {
		en: "South Korea’s second title, late in the China era.",
		ru: "Второй титул Южной Кореи, уже в конце эры Китая."
	},
	2007: {
		en: "Iran’s first title opens the West Asian window. The study notes China did not always send its strongest side, including in 2007.",
		ru: "Первый титул Ирана открывает окно Западной Азии. В работе отмечено: Китай не всегда выставлял сильнейший состав, в том числе в 2007."
	},
	2017: {
		en: "Oceania joins. The event is now the FIBA Asia Cup, on a four-year cycle, and Australia wins.",
		ru: "Входит Океания. Турнир становится FIBA Asia Cup на четырёхлетнем цикле, и побеждает Австралия."
	},
	2022: {
		en: "Australia again. The published calendar put this edition in Jakarta in July 2022, after a postponement from 2021.",
		ru: "Снова Австралия. В опубликованном календаре турнир прошёл в Джакарте в июле 2022-го, после переноса с 2021-го."
	},
	2025: {
		en: "Australia’s third title in three editions. For this window the HHI is 1.00.",
		ru: "Третий титул Австралии в трёх розыгрышах. Для этого окна HHI равен 1.00."
	}
};
function hhi(counts) {
	const total = counts.reduce((sum, n) => sum + n, 0);
	if (total <= 0) return 0;
	return counts.reduce((sum, n) => sum + (n / total) ** 2, 0);
}
function emptyCounts() {
	return {
		CHN: 0,
		PHI: 0,
		IRI: 0,
		AUS: 0,
		KOR: 0,
		JPN: 0
	};
}
function countsFor(editions) {
	const counts = emptyCounts();
	for (const edition of editions) counts[edition.team] += 1;
	return counts;
}
function summarize(editions) {
	const counts = countsFor(editions);
	const values = TEAM_IDS.map((id) => counts[id]);
	const total = editions.length;
	const index = hhi(values);
	let leader = "CHN";
	let best = -1;
	for (const id of TEAM_IDS) if (counts[id] > best) {
		best = counts[id];
		leader = id;
	}
	return {
		total,
		champions: TEAM_IDS.filter((id) => counts[id] > 0).length,
		hhi: index,
		leader,
		leaderShare: total ? best / total : 0,
		eff: index > 0 ? 1 / index : 0,
		counts
	};
}
function formatHhi(value) {
	return value.toFixed(2);
}
function formatShare(value) {
	return `${Math.round(value * 100)}%`;
}
function formatEff(value) {
	return value.toFixed(2);
}
var REFERENCES = [
	{ text: "Brieflands. (n.d.). Game-related statistics which discriminate between winning and losing teams in Asian and European men’s basketball championships. Authors, year and journal still to be completed on the poster." },
	{
		text: "FIBA. (n.d.). FIBA Asia Cup: History.",
		href: "https://www.fiba.basketball/en/history/195-fiba-asia-cup"
	},
	{ text: "Fort, R., & Maxcy, J. (2003). Competitive balance in sports leagues: An introduction. Journal of Sports Economics, 4(2), 154–160." },
	{ text: "Humphreys, B. R. (2002). Alternative measures of competitive balance in sports leagues. Journal of Sports Economics, 3(2), 133–148." },
	{ text: "Rottenberg, S. (1956). The baseball players’ labor market. Journal of Political Economy, 64(3), 242–258." },
	{ text: "SAGE Open. (2024). Market share instability and market concentration: A sport/discipline-specific study of the Summer Olympic Games 1992–2020. Authors, volume and DOI still to be completed on the poster." },
	{ text: "Truyens, J., De Bosscher, V., & Heyndels, B. Competitive balance in athletics. Managing Sport and Leisure. Year, volume and pages still to be completed on the poster." },
	{
		text: "Wikipedia contributors. (2026). FIBA Asia Cup. Accessed 3 November 2026.",
		href: "https://en.wikipedia.org/wiki/FIBA_Asia_Cup"
	},
	{
		text: "Supplementary finals, 2007–2025, checked against published tournament pages (not an input to the HHI): Wikipedia, 2022 FIBA Asia Cup; RealGM FIBA Asia Cup history. Accessed 3 November 2026.",
		href: "https://en.wikipedia.org/wiki/2022_FIBA_Asia_Cup"
	}
];
var ui = {
	ru: {
		skip: "К выводу",
		nav: {
			answer: "Вывод",
			years: "Годы",
			index: "Индекс",
			method: "Метод",
			meaning: "Смысл",
			sources: "Источники"
		},
		kicker: "Мини-исследование · 31 турнир",
		titleA: "Кто побеждает",
		titleB: "в азиатском баскетболе?",
		deck: "Концентрация титулов и конкурентный баланс на FIBA Asia Cup, 1960–2025.",
		byline: "Алдияр Аканов",
		questionLabel: "Вопрос",
		question: "Насколько сконцентрированы титулы FIBA Asia Cup и изменило ли включение Океании в 2017 году конкурентный баланс?",
		aimLabel: "Задача",
		aim: "Записать чемпионов всех 31 розыгрышей, посчитать HHI по четырём эрам и прочитать результат через теорию конкурентного баланса.",
		answerLabel: "Короткий ответ",
		answer: "Концентрация высокая и цикличная: общий HHI 0.32, 16 из 31 титула у Китая. Вход Океании в 2017-м баланс не улучшил — Австралия выиграла три турнира из трёх. Центр силы сдвинулся, а не размылся.",
		copyAnswer: "Скопировать ответ",
		copied: "Скопировано",
		statHhi: "0.32",
		statHhiLabel: "общий HHI титулов, 31 турнир",
		statChina: "16 / 31",
		statChinaLabel: "титулов Китая, все между 1975 и 2015",
		statAus: "18–0",
		statAusLabel: "серия Австралии на Asia Cup, 3 титула с 2017",
		yearsTitle: "Кто забирал кубок",
		yearsLead: "Шесть сборных побеждали хотя бы раз. Тридцать четыре выходили на турнир. Нажмите год или соберите эру — лента не выдумывает счёт, только чемпиона.",
		allEras: "Все эры",
		allTeams: "Все",
		tapYear: "Нажмите год, чтобы прочитать, что в нём важно для вопроса.",
		editionsNote: "На ленте розыгрыши, а не каждый календарный год. До 2015 турнир шёл раз в два года. С 2017 это отдельный FIBA Asia Cup.",
		championWord: "Чемпион",
		finalWord: "Финал",
		indexTitle: "Насколько это концентрировано",
		indexLead: "HHI — сумма квадратов долей титулов. Около 1/N это баланс, 1.00 значит один победитель. Среди шести чемпионов ровный дележ дал бы HHI 0.17. Фактические 0.32 почти вдвое выше: «эффективных» чемпионов всего 3.13.",
		colEra: "Эра",
		colEditions: "Турниры",
		colChampions: "Чемпионы",
		colHhi: "HHI",
		colLeader: "Доля лидера",
		colEff: "Эфф. чемпионы",
		allEra: "Все, 1960–2025",
		hhiCaption: "HHI титулов. 1.00 — одна сборная выигрывает всё. Цвет столбца — лидер эры.",
		medalTitle: "Титул — не вся глубина",
		medalLead: "Корея взяла лишь 2 золота, но 11 серебра и 12 бронзы. Япония — 2, 5 и 7. Одни титулы прячут, кто постоянно рядом с вершиной.",
		gold: "Золото",
		silver: "Серебро",
		bronze: "Бронза",
		eraName: {
			founding: "1960–1973",
			china: "1975–2005",
			west: "2007–2015",
			oceania: "2017–2025"
		},
		eraShort: {
			founding: "60–73",
			china: "75–05",
			west: "07–15",
			oceania: "17–25"
		},
		eraBody: {
			founding: "Семь турниров, три чемпиона. Филиппины берут четыре. HHI 0.43: уже тесно, но ещё не монополия. Япония и Корея уже в списке.",
			china: "Шестнадцать турниров. Китай — 14, плюс по одному у Филиппин (1985) и Кореи (1997). HHI 0.77, доля лидера 88%. Пик всей серии.",
			west: "Пять турниров, два чемпиона. Иран — 3, Китай — 2. HHI падает до 0.52. Финалы часто сводят Западную Азию с Восточной.",
			oceania: "Три турнира, один чемпион. Австралия 3 из 3, HHI 1.00. Океания перенесла центр силы, а не раздала титулы. В работе серия Австралии — 18–0."
		},
		threeKicker: "Рядом, но не в выборке",
		threeTitle: "3×3 — другая игра",
		threeBody: "Это исследование про классический FIBA Asia Cup, пять на пять. Уличный 3×3 — отдельное соревнование FIBA, его титулы сюда не входят. Кадр только задаёт атмосферу и не является архивным фото матча.",
		methodTitle: "Как посчитано",
		methodLead: "Количественный разбор всей совокупности: каждый розыгрыш, без выборки и без опросов. Эры нарезаны по слому формата, а не по красивой дате.",
		rows: [
			{
				k: "Подход",
				v: "Количественный, описательный, продольный анализ вторичных данных. Живых участников нет."
			},
			{
				k: "Почему так",
				v: "Исход — это счёт титулов, его можно сравнить между эрами одним числом."
			},
			{
				k: "Источник",
				v: "Чемпионы всех 31 розыгрышей, 1960–2025, по опубликованным протоколам турнира."
			},
			{
				k: "Совокупность",
				v: "Вся популяция. Эры: 1960–73; 1975–2005, дебют Китая; 2007–15, подъём Западной Азии; 2017–25, вход Океании."
			},
			{
				k: "Инструменты",
				v: "HHI = сумма квадратов долей; доля лидера; эффективное число чемпионов = 1/HHI."
			},
			{
				k: "Ход",
				v: "Список чемпионов, подсчёт по эрам, индексы, затем график."
			},
			{
				k: "Этика",
				v: "Только открытые данные. Источники названы. Ничего не выдумано и не подправлено."
			}
		],
		labTitle: "Покрутите индекс сами",
		labLead: "Это учебный стенд, не новые данные. Снимите титул у одной сборной и отдайте другой. Общее число титулов остаётся 31.",
		labHint: "Сначала минус, потом плюс у другой сборной.",
		labReset: "Вернуть факт",
		labNow: "Сейчас",
		labActual: "В исследовании",
		labPool: "В руках",
		labGive: "Забрать титул",
		labTake: "Отдать титул",
		meaningTitle: "Что из этого следует",
		bullets: [
			"Ровного тренда нет. Концентрация пиковая в эру Китая (1975–2005), ниже в 2007–2015, когда три титула берёт Иран, и снова 1.00 после 2017.",
			"Неожиданность гипотезы подтверждается: Океания не размазала успех. Австралия выиграла все три розыгрыша, центр силы переехал.",
			"Это стыкуется с Truyens et al. и SAGE Open (2024): концентрация держится, даже когда участников становится больше."
		],
		limitTitle: "Где работа слабее",
		limits: [
			"В последней эре всего три турнира. Один победитель автоматически даёт HHI 1.00.",
			"Китай не всегда выставлял сильнейший состав, например в 2007.",
			"Титулы не видят глубину медалей. Данные вторичные."
		],
		closeTitle: "Ответ на вопрос",
		closeBody: "Концентрация титулов на FIBA Asia Cup высокая и цикличная (общий HHI 0.32; 16 из 31 — у Китая). Вход Океании в 2017 году баланс не улучшил: Австралия лидирует с 3 из 3.",
		recs: "Дальше баланс лучше мерить медалями и топ-4, не только титулами. Имеет смысл добавить разницу в счёте и динамическую меру устойчивости чемпионов.",
		sourcesTitle: "Источники",
		sourcesNote: "Библиография как на постере. Где на постере стояла пометка «дописать автора», она сохранена — недостающее не додумано.",
		illus: "Кадры площадки и 3×3 — сгенерированные иллюстрации, не фото конкретных матчей и не портреты игроков. На них нельзя опираться как на доказательство.",
		footer: "Who Wins · мини-исследование по FIBA Asia Cup",
		heroAlt: "Иллюстрация: бросок в пустом свете ночной арены, без номеров и без узнаваемого лица.",
		threeAlt: "Иллюстрация: уличный момент 3×3 на закате, лица не читаются.",
		courtAlt: "Иллюстрация: пустая площадка и одно пятно тёплого света.",
		tunnelAlt: "Иллюстрация: силуэты игроков уходят с освещённой площадки в туннель."
	},
	en: {
		skip: "Skip to the answer",
		nav: {
			answer: "Answer",
			years: "Years",
			index: "Index",
			method: "Method",
			meaning: "Meaning",
			sources: "Sources"
		},
		kicker: "Mini research project · 31 editions",
		titleA: "Who wins",
		titleB: "in Asian basketball?",
		deck: "Title concentration and competitive balance at the FIBA Asia Cup, 1960–2025.",
		byline: "Aldiyar Akanov",
		questionLabel: "Question",
		question: "How concentrated are titles at the FIBA Asia Cup, and did the 2017 inclusion of Oceania change competitive balance?",
		aimLabel: "Aim",
		aim: "Record the champions of all 31 editions, compute the HHI for four eras, and read the result through competitive-balance theory.",
		answerLabel: "Short answer",
		answer: "Concentration is high and cyclical: overall HHI 0.32, with 16 of 31 titles to China. Oceania’s 2017 entry did not improve balance — Australia won three editions out of three. The centre of power moved. It did not spread.",
		copyAnswer: "Copy the answer",
		copied: "Copied",
		statHhi: "0.32",
		statHhiLabel: "overall HHI of titles, 31 editions",
		statChina: "16 / 31",
		statChinaLabel: "titles won by China, all of them 1975–2015",
		statAus: "18–0",
		statAusLabel: "Australia’s Asia Cup run, 3 titles since 2017",
		yearsTitle: "Who took the cup",
		yearsLead: "Six teams have won it. Thirty-four have played in it. Tap a year or an era. The ribbon records the champion, not a made-up score.",
		allEras: "All eras",
		allTeams: "All",
		tapYear: "Tap a year to read why it matters to the question.",
		editionsNote: "The ribbon is editions, not every calendar year. Through 2015 the cup was biennial. From 2017 it is a stand-alone FIBA Asia Cup.",
		championWord: "Champion",
		finalWord: "Final",
		indexTitle: "How concentrated that is",
		indexLead: "HHI is the sum of squared title shares. Near 1/N means balance; 1.00 means one winner. Split evenly among the six champions, HHI would be 0.17. The actual 0.32 is nearly twice as tight: only 3.13 effective champions.",
		colEra: "Era",
		colEditions: "Editions",
		colChampions: "Champions",
		colHhi: "HHI",
		colLeader: "Leader share",
		colEff: "Eff. champions",
		allEra: "All, 1960–2025",
		hhiCaption: "HHI of titles. 1.00 means one team wins everything. Bar colour is the era’s leader.",
		medalTitle: "A title is not the whole depth",
		medalLead: "Korea has only 2 golds, but 11 silvers and 12 bronzes. Japan has 2, 5 and 7. Titles alone hide who keeps finishing next to the top.",
		gold: "Gold",
		silver: "Silver",
		bronze: "Bronze",
		eraName: {
			founding: "1960–1973",
			china: "1975–2005",
			west: "2007–2015",
			oceania: "2017–2025"
		},
		eraShort: {
			founding: "60–73",
			china: "75–05",
			west: "07–15",
			oceania: "17–25"
		},
		eraBody: {
			founding: "Seven editions, three champions. The Philippines take four. HHI 0.43: already tight, not yet a monopoly. Japan and Korea are already on the roll.",
			china: "Sixteen editions. China 14, plus one each for the Philippines (1985) and Korea (1997). HHI 0.77, leader share 88%. The peak of the series.",
			west: "Five editions, two champions. Iran 3, China 2. HHI falls to 0.52. Finals often pair a West Asian side with an East Asian one.",
			oceania: "Three editions, one champion. Australia 3 of 3, HHI 1.00. Oceania moved the centre of power; it did not share the titles. The study records Australia at 18–0."
		},
		threeKicker: "Beside the sample, not in it",
		threeTitle: "3×3 is a different game",
		threeBody: "This study is the full-court FIBA Asia Cup. Outdoor 3×3 is a separate FIBA competition, and its titles are not in the count. The picture is atmosphere, not an archival match photo.",
		methodTitle: "How it was counted",
		methodLead: "A quantitative reading of the whole population: every edition, no sample, no interviews. Eras are cut on a structural break, not a round number.",
		rows: [
			{
				k: "Approach",
				v: "Quantitative, descriptive, longitudinal analysis of secondary data. No human participants."
			},
			{
				k: "Why",
				v: "Outcomes are title counts, so eras can be compared with one index."
			},
			{
				k: "Data",
				v: "Champions of all 31 editions, 1960–2025, from published tournament records."
			},
			{
				k: "Population",
				v: "Every edition. Eras: 1960–73; 1975–2005, China debuts; 2007–15, the West Asian rise; 2017–25, Oceania joins."
			},
			{
				k: "Instruments",
				v: "HHI = sum of squared title shares; the leader’s share; effective champions = 1/HHI."
			},
			{
				k: "Procedure",
				v: "List the champions, count titles per era, compute the indices, then chart them."
			},
			{
				k: "Ethics",
				v: "Public data only. Sources credited. Nothing invented or altered."
			}
		],
		labTitle: "Turn the index yourself",
		labLead: "A teaching bench, not new data. Take a title from one team and give it to another. The total stays 31.",
		labHint: "Minus first, then plus on a different team.",
		labReset: "Restore the record",
		labNow: "Now",
		labActual: "In the study",
		labPool: "In hand",
		labGive: "Take a title",
		labTake: "Give a title",
		meaningTitle: "What follows",
		bullets: [
			"No steady trend. Concentration peaks in the China era (1975–2005), eases in 2007–2015 when Iran wins three titles, then hits 1.00 after 2017.",
			"The hypothesis holds in the surprising direction: Oceania did not spread success. Australia won every edition, so the centre of power moved.",
			"That matches Truyens et al. and SAGE Open (2024): concentration persists even when more nations take part."
		],
		limitTitle: "Where the study is thin",
		limits: [
			"The last era has only three editions. One winner produces an HHI of 1.00 by arithmetic.",
			"China did not always field its strongest team, for example in 2007.",
			"Titles ignore medal depth. The data are secondary."
		],
		closeTitle: "Answer",
		closeBody: "Title concentration at the FIBA Asia Cup is high and cyclical (overall HHI 0.32; 16 of 31 titles to China). The 2017 entry of Oceania did not improve balance: Australia leads with 3 of 3 titles.",
		recs: "Judge balance with medals and top-four places, not titles alone. Later work should add game margins and a dynamic stability measure.",
		sourcesTitle: "Sources",
		sourcesNote: "The bibliography follows the poster. Where the poster still said to add an author, that gap is kept — it is not filled in.",
		illus: "Court and 3×3 frames are generated illustrations, not photos of particular matches or players. They are not evidence.",
		footer: "Who Wins · a mini study of the FIBA Asia Cup",
		heroAlt: "Illustration: a layup in a single pool of arena light, no numbers and no identifiable face.",
		threeAlt: "Illustration: an outdoor 3×3 moment at dusk, faces unreadable.",
		courtAlt: "Illustration: an empty court and one pool of warm light.",
		tunnelAlt: "Illustration: player silhouettes leaving a lit court for the tunnel."
	}
};
var LangContext = (0, import_react.createContext)({
	lang: "ru",
	setLang: () => void 0
});
function LangProvider({ children }) {
	const [lang, setLangState] = (0, import_react.useState)("ru");
	(0, import_react.useEffect)(() => {
		const saved = localStorage.getItem("ww-lang");
		if (saved === "en" || saved === "ru") setLangState(saved);
		document.documentElement.lang = saved === "en" ? "en" : "ru";
	}, []);
	const setLang = (next) => {
		setLangState(next);
		localStorage.setItem("ww-lang", next);
		document.documentElement.lang = next;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangContext.Provider, {
		value: {
			lang,
			setLang
		},
		children
	});
}
function useLang() {
	return (0, import_react.useContext)(LangContext);
}
function matches(editionEra, editionTeam, era, team) {
	return (era === "all" || editionEra === era) && (team === "all" || editionTeam === team);
}
function Timeline({ lang, text, era, team, year, onEra, onTeam, onYear }) {
	const selected = EDITIONS.find((edition) => edition.year === year) ?? null;
	const note = selected ? NOTES[selected.year] : void 0;
	const final = selected ? FINALS.find((row) => row.year === selected.year) : void 0;
	const eraMeta = selected ? ERAS.find((row) => row.id === selected.era) : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2 overflow-x-auto pb-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
				pressed: era === "all",
				onClick: () => onEra("all"),
				children: text.allEras
			}), ERAS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
				pressed: era === row.id,
				onClick: () => onEra(row.id),
				children: text.eraName[row.id]
			}, row.id))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 flex gap-2 overflow-x-auto pb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
				pressed: team === "all",
				onClick: () => onTeam("all"),
				children: text.allTeams
			}), TEAM_IDS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterChip, {
				pressed: team === id,
				onClick: () => onTeam(id),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `inline-block size-2.5 rounded-full ${TEAMS[id].swatch}`,
					"aria-hidden": true
				}), lang === "ru" ? TEAMS[id].ru : TEAMS[id].en]
			}, id))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-2 overflow-x-auto pb-2 snap-x snap-mandatory",
			children: EDITIONS.map((edition) => {
				const on = matches(edition.era, edition.team, era, team);
				const active = year === edition.year;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onYear(edition.year),
					"aria-pressed": active,
					className: `snap-start flex h-24 w-20 shrink-0 flex-col justify-between rounded-xl border px-2 py-2 text-left transition ${active ? "border-gold bg-panel" : on ? "border-line bg-court" : "border-line bg-ink opacity-35"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `h-1.5 w-8 rounded-full ${TEAMS[edition.team].swatch}`,
						"aria-hidden": true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-display text-lg leading-none text-fg",
						children: edition.team
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-xs text-muted",
						children: edition.year
					})] })]
				}, edition.year);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm leading-relaxed text-muted",
			children: text.editionsNote
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 rounded-xl border border-line bg-panel p-4",
			children: selected && eraMeta ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-gold uppercase",
					children: text.eraName[selected.era]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "mt-1 font-display text-3xl text-fg",
					children: [selected.year, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-3 text-xl text-muted",
						children: lang === "ru" ? TEAMS[selected.team].ru : TEAMS[selected.team].en
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-base leading-relaxed text-fg",
					children: note ? note[lang] : lang === "ru" ? `${TEAMS[selected.team].ru} побеждает в ${selected.year}. Окно «${text.eraName[selected.era]}».` : `${TEAMS[selected.team].en} wins ${selected.year}, inside the ${text.eraName[selected.era]} window.`
				}),
				final ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: [
						text.finalWord,
						": ",
						lang === "ru" ? TEAMS[selected.team].ru : TEAMS[selected.team].en,
						" – ",
						lang === "ru" ? final.runnerRu : final.runnerEn
					]
				}) : null
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-base leading-relaxed text-muted",
				children: text.tapYear
			})
		})
	] });
}
function FilterChip({ pressed, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": pressed,
		onClick,
		className: `inline-flex h-11 shrink-0 items-center gap-2 rounded-full border px-4 text-sm font-medium ${pressed ? "border-gold bg-gold text-ink" : "border-line bg-court text-fg"}`,
		children
	});
}
var LEADER_FILL = {
	CHN: "var(--color-team-chn)",
	PHI: "var(--color-team-phi)",
	IRI: "var(--color-team-iri)",
	AUS: "var(--color-team-aus)",
	KOR: "var(--color-team-kor)",
	JPN: "var(--color-team-jpn)"
};
function Charts({ text, langRu, era, onEra }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	const rows = [...ERAS.map((row) => {
		const summary = summarize(EDITIONS.filter((edition) => edition.era === row.id));
		return {
			id: row.id,
			label: text.eraShort[row.id],
			hhi: Number(summary.hhi.toFixed(2)),
			fill: LEADER_FILL[summary.leader]
		};
	}), {
		id: "all",
		label: langRu ? "все" : "all",
		hhi: Number(summarize(EDITIONS).hhi.toFixed(2)),
		fill: "var(--color-paper)"
	}];
	const medals = MEDALS.map((row) => ({
		code: row.team,
		name: langRu ? TEAMS[row.team].ru : TEAMS[row.team].en,
		g: row.g,
		s: row.s,
		b: row.b
	}));
	const tableEras = ERAS.map((row) => ({
		id: row.id,
		label: text.eraName[row.id],
		summary: summarize(EDITIONS.filter((edition) => edition.era === row.id))
	}));
	const all = summarize(EDITIONS);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-xl border border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[36rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-court text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: text.colEra
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: text.colEditions
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: text.colChampions
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: text.colHhi
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: text.colLeader
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: text.colEff
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [tableEras.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: era === row.id ? "bg-panel" : "bg-ink",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-t border-line px-3 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "font-medium text-fg",
									onClick: () => onEra(row.id),
									children: row.label
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-t border-line px-3 py-3 tabular-nums",
								children: row.summary.total
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-t border-line px-3 py-3 tabular-nums",
								children: row.summary.champions
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-t border-line px-3 py-3 font-display text-lg tabular-nums text-gold",
								children: formatHhi(row.summary.hhi)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "border-t border-line px-3 py-3",
								children: [
									formatShare(row.summary.leaderShare),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted",
										children: [
											"(",
											row.summary.leader,
											")"
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-t border-line px-3 py-3 tabular-nums",
								children: formatEff(row.summary.eff)
							})
						]
					}, row.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: era === "all" ? "bg-panel" : "bg-ink",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-t border-line px-3 py-3 font-medium",
								children: text.allEra
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-t border-line px-3 py-3 tabular-nums",
								children: all.total
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-t border-line px-3 py-3 tabular-nums",
								children: all.champions
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-t border-line px-3 py-3 font-display text-lg tabular-nums text-gold",
								children: formatHhi(all.hhi)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "border-t border-line px-3 py-3",
								children: [
									formatShare(all.leaderShare),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted",
										children: [
											"(",
											all.leader,
											")"
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-t border-line px-3 py-3 tabular-nums",
								children: formatEff(all.eff)
							})
						]
					})] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line bg-court p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-72",
					children: ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: rows,
							margin: {
								top: 8,
								right: 4,
								left: 0,
								bottom: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "label",
									tick: {
										fill: "var(--color-muted)",
										fontSize: 12
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									domain: [0, 1],
									ticks: [
										0,
										.25,
										.5,
										.75,
										1
									],
									tick: {
										fill: "var(--color-muted)",
										fontSize: 12
									},
									axisLine: false,
									tickLine: false,
									width: 36
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									cursor: { fill: "var(--color-panel)" },
									contentStyle: {
										background: "var(--color-panel)",
										border: "1px solid var(--color-line)",
										borderRadius: 12,
										color: "var(--color-fg)"
									},
									formatter: (value) => [typeof value === "number" ? value.toFixed(2) : value, "HHI"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "hhi",
									radius: [
										8,
										8,
										0,
										0
									],
									onClick: (state) => {
										const id = state.id;
										if (id) onEra(id);
									},
									children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
										fill: row.fill,
										stroke: era === row.id ? "var(--color-gold)" : "transparent",
										strokeWidth: era === row.id ? 2 : 0
									}, row.id))
								})
							]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full rounded-lg bg-panel" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: text.hhiCaption
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-3xl text-fg",
					children: text.medalTitle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-base leading-relaxed text-muted",
					children: text.medalLead
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex gap-4 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
								className: "inline-block size-2.5 rounded-full bg-gold",
								"aria-hidden": true
							}), text.gold]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
								className: "inline-block size-2.5 rounded-full bg-silver",
								"aria-hidden": true
							}), text.silver]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
								className: "inline-block size-2.5 rounded-full bg-bronze",
								"aria-hidden": true
							}), text.bronze]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 h-72 rounded-xl border border-line bg-court p-4",
					children: ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: medals,
							margin: {
								top: 8,
								right: 4,
								left: 0,
								bottom: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "code",
									tick: {
										fill: "var(--color-muted)",
										fontSize: 12
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									allowDecimals: false,
									tick: {
										fill: "var(--color-muted)",
										fontSize: 12
									},
									axisLine: false,
									tickLine: false,
									width: 28
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									cursor: { fill: "var(--color-panel)" },
									contentStyle: {
										background: "var(--color-panel)",
										border: "1px solid var(--color-line)",
										borderRadius: 12,
										color: "var(--color-fg)"
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "b",
									stackId: "medals",
									fill: "var(--color-bronze)",
									name: text.bronze
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "s",
									stackId: "medals",
									fill: "var(--color-silver)",
									name: text.silver
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "g",
									stackId: "medals",
									fill: "var(--color-gold)",
									name: text.gold,
									radius: [
										6,
										6,
										0,
										0
									]
								})
							]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full rounded-lg bg-panel" })
				})
			] })
		]
	});
}
function HhiLab({ lang, text }) {
	const actual = (0, import_react.useMemo)(() => countsFor(EDITIONS), []);
	const [counts, setCounts] = (0, import_react.useState)(actual);
	const [pool, setPool] = (0, import_react.useState)(0);
	const index = hhi(TEAM_IDS.map((id) => counts[id]));
	const actualIndex = hhi(TEAM_IDS.map((id) => actual[id]));
	const take = (id) => {
		if (counts[id] <= 0) return;
		setCounts({
			...counts,
			[id]: counts[id] - 1
		});
		setPool(pool + 1);
	};
	const give = (id) => {
		if (pool <= 0) return;
		setCounts({
			...counts,
			[id]: counts[id] + 1
		});
		setPool(pool - 1);
	};
	const reset = () => {
		setCounts({
			...emptyCounts(),
			...actual
		});
		setPool(0);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-line bg-court p-4 text-fg md:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-widest text-gold uppercase",
						children: text.labNow
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-5xl leading-none text-fg tabular-nums",
						children: formatHhi(index)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							"1/HHI = ",
							formatEff(index > 0 ? 1 / index : 0),
							" · ",
							text.labActual,
							" ",
							formatHhi(actualIndex),
							" · ",
							text.labPool,
							" ",
							pool
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: reset,
					className: "h-11 rounded-full border border-line px-4 text-sm font-medium text-fg",
					children: text.labReset
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm leading-relaxed text-muted",
				children: text.labHint
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 grid gap-2",
				children: TEAM_IDS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 rounded-xl bg-panel px-3 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `size-3 shrink-0 rounded-full ${TEAMS[id].swatch}`,
							"aria-hidden": true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 flex-1 text-sm text-fg",
							children: lang === "ru" ? TEAMS[id].ru : TEAMS[id].en
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-8 text-right font-display text-xl tabular-nums",
							children: counts[id]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": `${text.labGive}: ${TEAMS[id].en}`,
							disabled: counts[id] <= 0,
							onClick: () => take(id),
							className: "grid size-11 place-items-center rounded-full border border-line text-lg disabled:opacity-30",
							children: "−"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": `${text.labTake}: ${TEAMS[id].en}`,
							disabled: pool <= 0,
							onClick: () => give(id),
							className: "grid size-11 place-items-center rounded-full bg-gold text-lg text-ink disabled:opacity-30",
							children: "+"
						})
					]
				}, id))
			})
		]
	});
}
function ResearchPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {}) });
}
function Page() {
	const { lang, setLang } = useLang();
	const text = ui[lang];
	const [era, setEra] = (0, import_react.useState)("all");
	const [team, setTeam] = (0, import_react.useState)("all");
	const [year, setYear] = (0, import_react.useState)(1975);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const copyAnswer = async () => {
		try {
			await navigator.clipboard.writeText(text.answer);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1600);
		} catch {
			setCopied(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-ink text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#answer",
				className: "sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-30 focus:rounded-full focus:bg-gold focus:px-4 focus:py-3 focus:text-ink",
				children: text.skip
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 border-b border-line bg-ink/95 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-5xl items-center gap-3 px-4 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#top",
							className: "font-display text-lg text-fg",
							children: "Who Wins"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: "flex min-w-0 flex-1 gap-1 overflow-x-auto",
							"aria-label": "Sections",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
									href: "#answer",
									children: text.nav.answer
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
									href: "#years",
									children: text.nav.years
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
									href: "#index",
									children: text.nav.index
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
									href: "#method",
									children: text.nav.method
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
									href: "#meaning",
									children: text.nav.meaning
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
									href: "#sources",
									children: text.nav.sources
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex shrink-0 rounded-full border border-line p-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangButton, {
								current: lang,
								id: "ru",
								onPick: setLang,
								children: "RU"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangButton, {
								current: lang,
								id: "en",
								onPick: setLang,
								children: "EN"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "top",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative min-h-screen",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/images/arena.jpg",
								alt: text.heroAlt,
								className: "absolute inset-0 h-full w-full object-cover"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-ink/45" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 bottom-0 h-2/3 bg-ink/80" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative mx-auto flex min-h-screen max-w-5xl flex-col justify-end px-5 pt-24 pb-12",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium tracking-widest text-gold uppercase",
										children: text.kicker
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
										className: "mt-3 max-w-3xl font-display text-5xl leading-none text-fg md:text-7xl",
										children: [text.titleA, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block italic",
											children: text.titleB
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 max-w-xl text-lg leading-relaxed text-fg",
										children: text.deck
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-6 text-sm text-muted",
										children: text.byline
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "answer",
						className: "scroll-mt-16 border-t border-line",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-5xl gap-6 px-5 py-14 md:grid-cols-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium tracking-widest text-gold uppercase",
										children: text.questionLabel
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 font-display text-3xl leading-tight text-fg",
										children: text.question
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-4 text-sm leading-relaxed text-muted",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-medium text-fg",
											children: [text.aimLabel, ". "]
										}), text.aim]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl border border-gold bg-panel p-5 md:col-span-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium tracking-widest text-gold uppercase",
										children: text.answerLabel
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-base leading-relaxed text-fg",
										children: text.answer
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: copyAnswer,
										className: "mt-5 inline-flex h-11 items-center gap-2 rounded-full bg-gold px-4 text-sm font-medium text-ink",
										children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											className: "size-4",
											"aria-hidden": true
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
											className: "size-4",
											"aria-hidden": true
										}), copied ? text.copied : text.copyAnswer]
									})
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-5xl gap-3 px-5 pb-14 md:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									value: text.statHhi,
									label: text.statHhiLabel
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									value: text.statChina,
									label: text.statChinaLabel
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									value: text.statAus,
									label: text.statAusLabel
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "years",
						className: "scroll-mt-16 border-t border-line bg-court",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-5xl px-5 py-14",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
									title: text.yearsTitle,
									lead: text.yearsLead
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timeline, {
										lang,
										text,
										era,
										team,
										year,
										onEra: setEra,
										onTeam: setTeam,
										onYear: setYear
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8 grid gap-3 md:grid-cols-2",
									children: ERAS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setEra(row.id),
										"aria-pressed": era === row.id,
										className: `rounded-xl border p-4 text-left ${era === row.id ? "border-gold bg-panel" : "border-line bg-ink"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-medium tracking-widest text-gold uppercase",
											children: text.eraName[row.id]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm leading-relaxed text-fg",
											children: text.eraBody[row.id]
										})]
									}, row.id))
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "index",
						className: "scroll-mt-16 border-t border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-5xl px-5 py-14",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
								title: text.indexTitle,
								lead: text.indexLead
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-8",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Charts, {
									text,
									langRu: lang === "ru",
									era,
									onEra: setEra
								})
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "border-t border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-5xl items-center gap-6 px-5 py-14 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/images/three.jpg",
								alt: text.threeAlt,
								className: "aspect-3/2 w-full rounded-xl object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-widest text-gold uppercase",
									children: text.threeKicker
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-2 font-display text-4xl text-fg",
									children: text.threeTitle
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-base leading-relaxed text-muted",
									children: text.threeBody
								})
							] })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "method",
						className: "scroll-mt-16 border-t border-line bg-paper text-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-5xl gap-8 px-5 py-14 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-4xl",
									children: text.methodTitle
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-base leading-relaxed text-ink/75",
									children: text.methodLead
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/images/court.jpg",
									alt: text.courtAlt,
									className: "mt-6 aspect-video w-full rounded-xl object-cover"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
									className: "mt-6 divide-y divide-ink/15",
									children: text.rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-1 py-3 sm:grid-cols-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-sm font-medium",
											children: row.k
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "text-sm leading-relaxed text-ink/75 sm:col-span-2",
											children: row.v
										})]
									}, row.k))
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-3xl",
									children: text.labTitle
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 mb-4 text-sm leading-relaxed text-ink/75",
									children: text.labLead
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HhiLab, {
									lang,
									text
								})
							] })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "meaning",
						className: "scroll-mt-16 border-t border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-5xl gap-8 px-5 py-14 md:grid-cols-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-4xl text-fg",
										children: text.meaningTitle
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-6 grid gap-4",
										children: text.bullets.map((bullet) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
											className: "border-l-2 border-gold pl-4 text-base leading-relaxed text-fg",
											children: bullet
										}, bullet))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-10 font-display text-2xl text-fg",
										children: text.limitTitle
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-4 grid gap-3",
										children: text.limits.map((limit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
											className: "text-sm leading-relaxed text-muted",
											children: limit
										}, limit))
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/images/tunnel.jpg",
									alt: text.tunnelAlt,
									className: "aspect-3/2 w-full rounded-xl object-cover"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 rounded-xl bg-gold p-5 text-ink",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-display text-2xl",
											children: text.closeTitle
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-sm leading-relaxed",
											children: text.closeBody
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-sm leading-relaxed",
											children: text.recs
										})
									]
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "sources",
						className: "scroll-mt-16 border-t border-line bg-court",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-5xl px-5 py-14",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-4xl text-fg",
									children: text.sourcesTitle
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 max-w-2xl text-sm leading-relaxed text-muted",
									children: text.sourcesNote
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
									className: "mt-6 grid gap-3",
									children: REFERENCES.map((ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "text-sm leading-relaxed text-fg",
										children: ref.href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: ref.href,
											className: "underline decoration-line underline-offset-4",
											children: ref.text
										}) : ref.text
									}, ref.text))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-8 max-w-2xl text-sm leading-relaxed text-muted",
									children: text.illus
								})
							]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-line px-5 py-8 text-center text-sm text-muted",
				children: text.footer
			})
		]
	});
}
function NavLink({ href, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href,
		className: "inline-flex h-11 shrink-0 items-center px-2 text-sm text-muted",
		children
	});
}
function LangButton({ current, id, onPick, children }) {
	const on = current === id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		onClick: () => onPick(id),
		className: `h-9 rounded-full px-3 text-sm font-medium ${on ? "bg-gold text-ink" : "text-muted"}`,
		children
	});
}
function Stat({ value, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-line bg-court px-4 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-4xl text-gold tabular-nums",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-relaxed text-muted",
			children: label
		})]
	});
}
function SectionTitle({ title, lead }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-2xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-4xl text-fg",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-base leading-relaxed text-muted",
			children: lead
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResearchPage, {});
}
//#endregion
export { Home as component };
